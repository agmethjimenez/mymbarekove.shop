<?php
require_once("../database/conexion.php");
class Producto
{
    private $id_producto;
    private $nombre;
    private $descripcion;
    private $precio;
    private $marca;
    private $categoria;
    private $proveedor;
    private $contenido;
    private $stock;
    private $imagen;

    public function setIdProducto($id){
        $this->id_producto = $id;
    }
    public function setNombre($nombre){
        $this->nombre = $nombre;
    }
    public function setDescripcion($descripcion){
        $this->descripcion = $descripcion;
    }
    public function setPrecio($precio){
        $this->precio = $precio;
    }
    public function setMarca($marca){
        $this->marca = $marca;
    }
    public function setProveedor($provedor){
        $this->proveedor = $provedor;
    }
    public function setCategoria($categoria){
        $this->categoria = $categoria;
    }
    public function setContenido($contenido){
        $this->contenido = $contenido;
    }
    public function setStock($stock){
        $this->stock = $stock;
    }
    public function setImagen($imagen){
        $this->imagen = $imagen;
    }

    public function GetProductos($conexion,$id){
        if($id === null){
            $sql = "SELECT p.idProducto, pr.nombreP, p.nombre, p.descripcionP, p.contenido, p.precio, m.marca, c.descripcion,p.cantidadDisponible, p.imagen FROM productos as p 
        INNER JOIN proveedores as pr ON p.proveedor = pr.idProveedor
        INNER JOIN marcas as m ON p.marca = m.idMarca
        INNER JOIN categorias as c ON p.categoria = c.categoria
        WHERE p.activo = 1";
        }else{
            $sql = "SELECT p.idProducto, pr.nombreP, p.nombre, p.descripcionP, p.contenido, p.precio, m.marca, c.descripcion,p.cantidadDisponible, p.imagen FROM productos as p 
        INNER JOIN proveedores as pr ON p.proveedor = pr.idProveedor
        INNER JOIN marcas as m ON p.marca = m.idMarca
        INNER JOIN categorias as c ON p.categoria = c.categoria
        WHERE p.activo = 1 AND idProducto = $id";
        }
        
    $resultados = array();

        if ($resultado = $conexion->query($sql)) {
            while ($fila = $resultado->fetch_assoc()) {
                $resultados[] = $fila;
            }
            $resultado->free();
        }
        return $resultados;
}
    
    public function AgregarProducto($conexion){
        global $conexion;
        $id = rand(1000,9999);
        $sql = "INSERT INTO productos(idProducto,proveedor, nombre, descripcionP, contenido, precio, marca, categoria, cantidadDisponible, imagen,activo) VALUES (?,?,?,?,?,?,?,?,?,?,1)";
        $bin = $conexion->prepare($sql);
        $bin->bind_param("ssssssssss",$this->id_producto,$this->proveedor,$this->nombre,$this->descripcion,$this->contenido,$this->precio, $this->marca, $this->categoria, $this->stock,$this->imagen);
        if($bin->execute()){
            return["accesso"=>true,"mensaje"=>"Producto Agregado exitosamente"];
        }else{
            return["accesso"=>false,"mensaje"=>"Producto no agregado"];
        }
    }
}

    

?>
